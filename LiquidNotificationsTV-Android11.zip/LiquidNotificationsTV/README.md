# Liquid Notifications TV

Android 11 / Google TV notification center designed for landscape TV screens.

## Included
- NotificationListenerService reads notification posts from other apps.
- ALL APPS mode or SELECTED APPS mode.
- Liquid-glass style notification popups using lightweight Android drawing (no heavy UI dependency).
- Notification Center with saved notifications and dismiss/clear actions.
- Overlay permission and Notification Access setup buttons.
- Popup duration, saved-notification limit, app-icon toggle, and accent controls.
- Configurable Boss Key.
- Optional AccessibilityService for a global Boss Key on supported TV remotes.
- Java-only, dependency-light project for easier AndroidIDE/AIDE builds.

## Android 11 setup on the TV
1. Install the APK.
2. Open Liquid Notifications TV.
3. Turn on Notification Access for the app.
4. Turn on Display over other apps.
5. Choose ALL APPS or SELECTED APPS.
6. For a global Boss Key, open High Customization, set the key, then enable the optional Accessibility service.

## Important platform note
Android does not expose a universal API that lets a normal app globally capture every arbitrary hardware/remote button. The optional Accessibility service uses Android key-event filtering for the Boss Key. Whether a particular TV firmware forwards a chosen remote key to accessibility depends on that firmware.

## Build
Use Android Gradle Plugin 7.4.2, compileSdk 30, minSdk 26, targetSdk 30. The project intentionally avoids AndroidX/UI libraries so it can be imported more easily into AndroidIDE/AIDE.

### Customization in v1
Popup duration, maximum history size, app icons, four glass accents, and four popup positions are configurable from the TV UI.

package com.purno.liquidnotifications;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;

public final class Glass {
    public static GradientDrawable bg(int fill, float radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill); d.setCornerRadius(radius); d.setStroke(2, strokeColor); return d;
    }
    public static void focus(View v) {
        v.setFocusable(true); v.setFocusableInTouchMode(false);
        v.setOnFocusChangeListener((view, has) -> {
            if (has) view.setBackground(bg(0xC0354860, 28, 0xB9FFFFFF));
            else view.setBackground(bg(0x7A1F2B3C, 28, 0x4DFFFFFF));
        });
    }
}

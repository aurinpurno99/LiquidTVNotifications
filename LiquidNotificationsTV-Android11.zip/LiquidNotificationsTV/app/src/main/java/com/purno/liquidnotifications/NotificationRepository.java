package com.purno.liquidnotifications;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class NotificationRepository {
    private static final String PREF = "notif_store";
    private static final String KEY = "items";
    private static final Object LOCK = new Object();

    public static final class Item {
        public String key, pkg, app, title, text;
        public long time;
        public Item(String key, String pkg, String app, String title, String text, long time) {
            this.key=key; this.pkg=pkg; this.app=app; this.title=title; this.text=text; this.time=time;
        }
    }

    public static void add(Context c, Item item) {
        synchronized (LOCK) {
            List<Item> list = load(c);
            for (int i=0;i<list.size();i++) if (list.get(i).key.equals(item.key)) { list.remove(i); break; }
            list.add(0, item);
            int max = AppPrefs.maxNotifications(c);
            while (list.size() > max) list.remove(list.size()-1);
            save(c, list);
        }
    }

    public static void remove(Context c, String key) {
        synchronized (LOCK) {
            List<Item> list = load(c);
            for (int i=0;i<list.size();i++) if (list.get(i).key.equals(key)) { list.remove(i); break; }
            save(c, list);
        }
    }

    public static void clear(Context c) { synchronized (LOCK) { save(c, new ArrayList<Item>()); } }

    public static List<Item> load(Context c) {
        synchronized (LOCK) {
            ArrayList<Item> out = new ArrayList<>();
            String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
            try {
                JSONArray a = new JSONArray(raw);
                for (int i=0;i<a.length();i++) {
                    JSONObject o=a.getJSONObject(i);
                    out.add(new Item(o.optString("key"),o.optString("pkg"),o.optString("app"),o.optString("title"),o.optString("text"),o.optLong("time")));
                }
            } catch(Exception ignored) {}
            return out;
        }
    }

    private static void save(Context c, List<Item> list) {
        JSONArray a = new JSONArray();
        try {
            for (Item n : list) {
                JSONObject o = new JSONObject();
                o.put("key", n.key); o.put("pkg", n.pkg); o.put("app", n.app); o.put("title", n.title); o.put("text", n.text); o.put("time", n.time);
                a.put(o);
            }
        } catch(Exception ignored) {}
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply();
    }

    public static Drawable appIcon(Context c, String pkg) {
        try { return c.getPackageManager().getApplicationIcon(pkg); } catch (PackageManager.NameNotFoundException e) { return c.getDrawable(R.drawable.ic_notification); }
    }

    public static void launchApp(Context c, String pkg) {
        try {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); }
        } catch (Exception ignored) {}
    }
}

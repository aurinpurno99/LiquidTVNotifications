package com.purno.liquidnotifications;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.Set;

public class NotificationListener extends NotificationListenerService {
    private static NotificationListener instance;
    public static NotificationListener getInstance() { return instance; }

    @Override public void onListenerConnected() { instance=this; }
    @Override public void onListenerDisconnected() { if(instance==this) instance=null; }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getPackageName().equals(getPackageName())) return;
        if (!AppPrefs.allowAll(this)) {
            Set<String> selected=AppPrefs.selectedPackages(this);
            if (!selected.contains(sbn.getPackageName())) return;
        }
        Notification n=sbn.getNotification();
        if (n==null) return;
        Bundle e=n.extras;
        String title=e!=null?e.getString(Notification.EXTRA_TITLE, "Notification"):"Notification";
        CharSequence tc=e!=null?e.getCharSequence(Notification.EXTRA_TEXT):null;
        String text=tc==null?"":tc.toString();
        String app="";
        try { app=(String)getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(sbn.getPackageName(),0)); }
        catch(Exception ignored) { app=sbn.getPackageName(); }
        NotificationRepository.Item item=new NotificationRepository.Item(
                sbn.getKey(), sbn.getPackageName(), app, title==null?"Notification":title, text, System.currentTimeMillis());
        NotificationRepository.add(this,item);
        PopupController.show(this,item);
        sendBroadcast(new Intent(MainActivity.ACTION_CHANGED).setPackage(getPackageName()));
    }

    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn!=null) NotificationRepository.remove(this,sbn.getKey());
        sendBroadcast(new Intent(MainActivity.ACTION_CHANGED).setPackage(getPackageName()));
    }
}

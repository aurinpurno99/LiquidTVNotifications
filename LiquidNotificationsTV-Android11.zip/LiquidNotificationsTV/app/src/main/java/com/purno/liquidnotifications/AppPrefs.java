package com.purno.liquidnotifications;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;
import java.util.HashSet;
import java.util.Set;

public final class AppPrefs {
    private static final String PREF = "liquid_prefs";
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public static boolean allowAll(Context c) { return p(c).getBoolean("allow_all", true); }
    public static void setAllowAll(Context c, boolean v) { p(c).edit().putBoolean("allow_all", v).apply(); }

    public static Set<String> selectedPackages(Context c) { return new HashSet<>(p(c).getStringSet("selected", new HashSet<String>())); }
    public static void setSelectedPackages(Context c, Set<String> s) { p(c).edit().putStringSet("selected", new HashSet<>(s)).apply(); }

    public static int popupSeconds(Context c) { return p(c).getInt("popup_seconds", 5); }
    public static void setPopupSeconds(Context c, int v) { p(c).edit().putInt("popup_seconds", Math.max(1, Math.min(20, v))).apply(); }

    public static int maxNotifications(Context c) { return p(c).getInt("max_notifications", 100); }
    public static void setMaxNotifications(Context c, int v) { p(c).edit().putInt("max_notifications", Math.max(20, Math.min(300, v))).apply(); }

    public static boolean showIcons(Context c) { return p(c).getBoolean("show_icons", true); }
    public static void setShowIcons(Context c, boolean v) { p(c).edit().putBoolean("show_icons", v).apply(); }

    public static int accentIndex(Context c) { return p(c).getInt("accent", 0); }
    public static void setAccentIndex(Context c, int i) { p(c).edit().putInt("accent", i).apply(); }

    public static int bossKey(Context c) { return p(c).getInt("boss_key", KeyEvent.KEYCODE_MENU); }
    public static void setBossKey(Context c, int code) { p(c).edit().putInt("boss_key", code).apply(); }

    public static String popupPosition(Context c) { return p(c).getString("popup_position", "top_right"); }
    public static void setPopupPosition(Context c, String s) { p(c).edit().putString("popup_position", s).apply(); }

    public static int accentColor(Context c) {
        int[] a={0xFF8BD7FF,0xFFB78BFF,0xFF72E0C1,0xFFFFC783};
        int i=accentIndex(c); return a[Math.max(0,Math.min(a.length-1,i))];
    }
}

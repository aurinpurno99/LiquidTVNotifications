package com.purno.liquidnotifications;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.View;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class NotificationCenterActivity extends Activity {
    private LinearLayout list; private TextView count;
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    @Override protected void onResume(){super.onResume();refresh();}
    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(Ui.dp(this,52),Ui.dp(this,30),Ui.dp(this,52),Ui.dp(this,30));
        android.widget.FrameLayout frame=new android.widget.FrameLayout(this); frame.addView(new GlassBackground(this),new android.widget.FrameLayout.LayoutParams(-1,-1)); frame.addView(root,new android.widget.FrameLayout.LayoutParams(-1,-1)); setContentView(frame);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=Ui.label(this,"Notification Center",31); t.setTypeface(null,Typeface.BOLD); head.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,58),1));
        count=Ui.label(this,"",15); count.setTextColor(0xB9D2E5); head.addView(count,new LinearLayout.LayoutParams(Ui.dp(this,220),Ui.dp(this,58))); 
        android.widget.Button clear=Ui.button(this,"Clear All"); clear.setOnClickListener(v->{NotificationRepository.clear(this);refresh();}); head.addView(clear,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,58))); root.addView(head);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,Ui.dp(this,18),0,0); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void refresh(){ if(list==null)return; list.removeAllViews(); List<NotificationRepository.Item> items=NotificationRepository.load(this); count.setText(items.size()+" saved");
        if(items.isEmpty()){TextView empty=Ui.label(this,"No notifications yet. Turn on Notification Access and send a notification.",18); empty.setGravity(Gravity.CENTER); list.addView(empty,new LinearLayout.LayoutParams(-1,Ui.dp(this,180))); return;}
        for(NotificationRepository.Item n:items) addCard(n);
    }
    private void addCard(NotificationRepository.Item n){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(Ui.dp(this,22),Ui.dp(this,16),Ui.dp(this,22),Ui.dp(this,16)); card.setBackground(Glass.panel(this)); Glass.focus(card); card.setOnClickListener(v->NotificationRepository.launchApp(this,n.pkg));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView app=Ui.label(this,n.app,14); app.setTextColor(0xB9D2E5); top.addView(app,new LinearLayout.LayoutParams(0,Ui.dp(this,28),1)); TextView time=Ui.label(this,DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(n.time)),12); time.setTextColor(0x99C0D5); top.addView(time,new LinearLayout.LayoutParams(Ui.dp(this,120),Ui.dp(this,28))); card.addView(top);
        TextView title=Ui.label(this,n.title,19); title.setTypeface(null,Typeface.BOLD); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END); card.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,32)));
        TextView text=Ui.label(this,n.text,15); text.setTextColor(0xD2E7F3); text.setMaxLines(3); text.setEllipsize(android.text.TextUtils.TruncateAt.END); card.addView(text,new LinearLayout.LayoutParams(-1,Ui.dp(this,56)));
        android.widget.Button del=Ui.button(this,"Dismiss"); del.setOnClickListener(v->{NotificationRepository.remove(this,n.key);refresh();}); card.addView(del,new LinearLayout.LayoutParams(Ui.dp(this,150),Ui.dp(this,56)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,Ui.dp(this,174)); cp.bottomMargin=Ui.dp(this,12); list.addView(card,cp);
    }
    @Override public boolean onKeyDown(int code,KeyEvent e){if(code==KeyEvent.KEYCODE_BACK){finish();return true;}return super.onKeyDown(code,e);}
}

package com.purno.liquidnotifications;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class BossKeyAccessibilityService extends AccessibilityService {
    @Override protected void onServiceConnected(){
        AccessibilityServiceInfo i=getServiceInfo();
        i.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        setServiceInfo(i);
    }
    @Override public boolean onKeyEvent(KeyEvent e){
        if(e.getAction()==KeyEvent.ACTION_DOWN && e.getRepeatCount()==0 && e.getKeyCode()==AppPrefs.bossKey(this)){
            Intent i=new Intent(this,NotificationCenterActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i); return true;
        }
        return super.onKeyEvent(e);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
}

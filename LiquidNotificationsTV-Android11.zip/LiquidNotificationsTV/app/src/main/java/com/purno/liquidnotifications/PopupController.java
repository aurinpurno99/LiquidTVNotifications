package com.purno.liquidnotifications;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayDeque;
import java.util.Deque;

public final class PopupController {
    private static final Handler H=new Handler(Looper.getMainLooper());
    private static final Deque<NotificationRepository.Item> QUEUE=new ArrayDeque<>();
    private static View current;
    private static WindowManager wm;
    private static Runnable hide;

    public static void show(Context c, NotificationRepository.Item item) {
        synchronized (QUEUE) {
            QUEUE.offer(item);
            if (current==null) H.post(() -> showNext(c.getApplicationContext()));
        }
    }

    private static void showNext(Context c) {
        NotificationRepository.Item item;
        synchronized (QUEUE) { item=QUEUE.poll(); }
        if(item==null || !AppPrefs.allowAll(c) && !AppPrefs.selectedPackages(c).contains(item.pkg)) { current=null; return; }
        if(!hasOverlay(c)) { current=null; return; }
        wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(c); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(Ui.dp(c,18),Ui.dp(c,14),Ui.dp(c,18),Ui.dp(c,14));
        box.setBackground(Glass.bg(0xE9263447,Ui.dp(c,24),0x66777777 | (AppPrefs.accentColor(c) & 0x00FFFFFF)));
        if(AppPrefs.showIcons(c)) {
            ImageView iv=new ImageView(c); iv.setImageDrawable(NotificationRepository.appIcon(c,item.pkg)); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            box.addView(iv,new LinearLayout.LayoutParams(Ui.dp(c,46),Ui.dp(c,46)));
        }
        LinearLayout texts=new LinearLayout(c); texts.setOrientation(LinearLayout.VERTICAL); texts.setPadding(Ui.dp(c,14),0,0,0);
        TextView app=Ui.label(c,item.app,13); app.setTextColor(0xB9D2E5);
        TextView title=Ui.label(c,item.title,19); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView text=Ui.label(c,item.text,15); text.setTextColor(0xD9EAF5); text.setMaxLines(2); text.setEllipsize(android.text.TextUtils.TruncateAt.END);
        texts.addView(app,new LinearLayout.LayoutParams(-1,Ui.dp(c,24))); texts.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(c,30))); texts.addView(text,new LinearLayout.LayoutParams(-1,Ui.dp(c,42))); box.addView(texts,new LinearLayout.LayoutParams(Ui.dp(c,500),-2));
        box.setOnClickListener(v->NotificationRepository.launchApp(c,item.pkg));
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(Ui.dp(c,590),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,-3);
        String pos=AppPrefs.popupPosition(c);
        if("top_left".equals(pos)){lp.gravity=Gravity.TOP|Gravity.START;lp.x=Ui.dp(c,26);lp.y=Ui.dp(c,28);}
        else if("bottom_left".equals(pos)){lp.gravity=Gravity.BOTTOM|Gravity.START;lp.x=Ui.dp(c,26);lp.y=Ui.dp(c,36);}
        else if("bottom_right".equals(pos)){lp.gravity=Gravity.BOTTOM|Gravity.END;lp.x=Ui.dp(c,26);lp.y=Ui.dp(c,36);}
        else {lp.gravity=Gravity.TOP|Gravity.END;lp.x=Ui.dp(c,26);lp.y=Ui.dp(c,28);}
        try { wm.addView(box,lp); current=box; } catch(Exception e) { current=null; return; }
        int ms=AppPrefs.popupSeconds(c)*1000;
        hide=()->{ if(current!=null){try{wm.removeView(current);}catch(Exception ignored){} current=null;} showNext(c); };
        H.postDelayed(hide,ms);
    }
    private static boolean hasOverlay(Context c) { return android.provider.Settings.canDrawOverlays(c); }
}

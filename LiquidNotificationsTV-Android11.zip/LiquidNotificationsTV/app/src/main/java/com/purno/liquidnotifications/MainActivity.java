package com.purno.liquidnotifications;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    public static final String ACTION_CHANGED="com.purno.liquidnotifications.CHANGED";
    private TextView status;
    @Override protected void onCreate(Bundle b) { super.onCreate(b); build(); }
    @Override protected void onResume() { super.onResume(); if(status!=null) refresh(); }

    private void build() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(Ui.dp(this,54),Ui.dp(this,34),Ui.dp(this,54),Ui.dp(this,34)); root.setBackgroundColor(Color.TRANSPARENT);
        GlassBackground bg=new GlassBackground(this);
        android.widget.FrameLayout frame=new android.widget.FrameLayout(this); frame.addView(bg,new android.widget.FrameLayout.LayoutParams(-1,-1)); frame.addView(root,new android.widget.FrameLayout.LayoutParams(-1,-1)); setContentView(frame);

        TextView title=Ui.label(this,"LIQUID NOTIFICATIONS",31); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        TextView sub=Ui.label(this,"A glass-style notification hub for Google TV",16); sub.setTextColor(0xB9D2E5); root.addView(sub,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,Ui.dp(this,14),0,Ui.dp(this,14));
        status=Ui.label(this,"",18); row.addView(status,new LinearLayout.LayoutParams(0,Ui.dp(this,70),1));
        TextView badge=Ui.label(this,"BOSS KEY",13); badge.setGravity(Gravity.CENTER); badge.setBackground(Glass.bg(0x8F263D52,Ui.dp(this,18),0x55FFFFFF)); row.addView(badge,new LinearLayout.LayoutParams(Ui.dp(this,140),Ui.dp(this,46))); root.addView(row);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.VERTICAL);
        addButton(buttons,"Open Notification Center",v->startActivity(new Intent(this,NotificationCenterActivity.class)));
        addButton(buttons,"Notification Access",v->startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        addButton(buttons,"Display Over Other Apps",v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))));
        addButton(buttons,"Choose Apps",v->startActivity(new Intent(this,AppsActivity.class)));
        addButton(buttons,"High Customization",v->startActivity(new Intent(this,SettingsActivity.class)));
        root.addView(buttons,new LinearLayout.LayoutParams(-1,0,1));

        TextView hint=Ui.label(this,"Remote tips: D-pad / OK • Boss Key can be mapped in Customization",14); hint.setTextColor(0x94C3D7E8); root.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        refresh();
    }
    private void addButton(LinearLayout p,String text,View.OnClickListener l){android.widget.Button b=Ui.button(this,text); b.setOnClickListener(l); p.addView(b,new LinearLayout.LayoutParams(-1,Ui.dp(this,62))); LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)b.getLayoutParams(); lp.bottomMargin=Ui.dp(this,8); b.setLayoutParams(lp);}
    private void refresh(){
        boolean access=false; try{android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE); java.util.Set<String> listeners=nm.getEnabledNotificationListenerPackages(this); access=listeners.contains(getPackageName());}catch(Exception ignored){}
        boolean overlay=Settings.canDrawOverlays(this);
        status.setText("Notification Access: "+(access?"READY":"OFF")+"     •     Overlay: "+(overlay?"READY":"OFF")+"     •     Mode: "+(AppPrefs.allowAll(this)?"ALL APPS":"SELECTED APPS"));
    }
    @Override public boolean onKeyDown(int code,KeyEvent e){ if(code==AppPrefs.bossKey(this)){ startActivity(new Intent(this,NotificationCenterActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)); return true;} return super.onKeyDown(code,e); }
}

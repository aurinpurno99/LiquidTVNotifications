package com.purno.liquidnotifications;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public final class Ui {
    public static int dp(Context c, int v) { return Math.round(v*c.getResources().getDisplayMetrics().density); }
    public static TextView label(Context c, String s, float sp) {
        TextView t=new TextView(c); t.setText(s); t.setTextColor(0xFFF7FBFF); t.setTextSize(sp); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    public static Button button(Context c, String s) {
        Button b=new Button(c); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setAllCaps(false); b.setMinHeight(dp(c,58));
        b.setPadding(dp(c,22),0,dp(c,22),0); b.setBackground(Glass.bg(0x7A1F2B3C, dp(c,18), 0x4DFFFFFF)); Glass.focus(b); return b;
    }
    public static GradientDrawable panel(Context c) { return Glass.bg(0x8F1E2A3B, dp(c,28), 0x40FFFFFF); }
}

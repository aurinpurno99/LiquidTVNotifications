package com.purno.liquidnotifications;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppsActivity extends Activity {
    private LinearLayout list;
    private CheckBox all;
    private final Set<String> selected=new HashSet<>();
    private final List<ApplicationInfo> apps=new ArrayList<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);selected.addAll(AppPrefs.selectedPackages(this));build();loadApps();}
    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(Ui.dp(this,50),Ui.dp(this,28),Ui.dp(this,50),Ui.dp(this,28));
        android.widget.FrameLayout frame=new android.widget.FrameLayout(this); frame.addView(new GlassBackground(this),new android.widget.FrameLayout.LayoutParams(-1,-1)); frame.addView(root,new android.widget.FrameLayout.LayoutParams(-1,-1)); setContentView(frame);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=Ui.label(this,"Notification Sources",30); t.setTypeface(null,Typeface.BOLD); head.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,60),1));
        all=new CheckBox(this); all.setText("Allow all apps"); all.setTextColor(0xFFF7FBFF); all.setTextSize(17); all.setChecked(AppPrefs.allowAll(this)); all.setOnCheckedChangeListener((b,checked)->{AppPrefs.setAllowAll(this,checked);setRowsEnabled(!checked);}); head.addView(all); root.addView(head);
        TextView hint=Ui.label(this,"ALL = every app can create a popup. SELECTED = only checked apps can create popups.",14); hint.setTextColor(0xA8C6D8); root.addView(hint,new LinearLayout.LayoutParams(-1,Ui.dp(this,34)));
        ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,Ui.dp(this,12),0,Ui.dp(this,20)); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void loadApps(){
        PackageManager pm=getPackageManager(); apps.clear();
        Intent launcher=new Intent(Intent.ACTION_MAIN); launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ApplicationInfo> found=pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for(ApplicationInfo a:found){
            if(a.packageName.equals(getPackageName())) continue;
            if(pm.getLaunchIntentForPackage(a.packageName)!=null) apps.add(a);
        }
        Collections.sort(apps, Comparator.comparing(a->pm.getApplicationLabel(a).toString().toLowerCase()));
        for(ApplicationInfo a:apps) addRow(a);
        setRowsEnabled(!AppPrefs.allowAll(this));
    }
    private void addRow(ApplicationInfo info){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(Ui.dp(this,18),Ui.dp(this,6),Ui.dp(this,18),Ui.dp(this,6)); row.setBackground(Glass.bg(0x6B203042,Ui.dp(this,20),0x36FFFFFF)); Glass.focus(row);
        TextView name=Ui.label(this,getPackageManager().getApplicationLabel(info).toString(),18); row.addView(name,new LinearLayout.LayoutParams(0,Ui.dp(this,66),1));
        TextView pkg=Ui.label(this,info.packageName,12); pkg.setTextColor(0x829BB2C3); row.addView(pkg,new LinearLayout.LayoutParams(Ui.dp(this,360),Ui.dp(this,66)));
        CheckBox box=new CheckBox(this); box.setChecked(selected.contains(info.packageName)); box.setOnCheckedChangeListener((button,checked)->{if(checked)selected.add(info.packageName);else selected.remove(info.packageName);AppPrefs.setSelectedPackages(this,selected);}); row.addView(box,new LinearLayout.LayoutParams(Ui.dp(this,70),Ui.dp(this,66)));
        row.setOnClickListener(v->box.setChecked(!box.isChecked())); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,78)); lp.bottomMargin=Ui.dp(this,8); list.addView(row,lp);
    }
    private void setRowsEnabled(boolean enabled){if(list==null)return;for(int i=0;i<list.getChildCount();i++) setEnabledRecursive(list.getChildAt(i),enabled);}
    private void setEnabledRecursive(View v,boolean enabled){v.setEnabled(enabled);if(v instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)v;for(int i=0;i<g.getChildCount();i++)setEnabledRecursive(g.getChildAt(i),enabled);}}
}

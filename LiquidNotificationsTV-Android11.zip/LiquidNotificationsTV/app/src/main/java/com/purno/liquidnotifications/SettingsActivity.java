package com.purno.liquidnotifications;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    private TextView popupValue,maxValue,keyValue; private boolean capturing=false; private Button keyButton;
    private final int[] accents={0xFF8BD7FF,0xFFB78BFF,0xFF72E0C1,0xFFFFC783};
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(Ui.dp(this,52),Ui.dp(this,28),Ui.dp(this,52),Ui.dp(this,26));
        android.widget.FrameLayout frame=new android.widget.FrameLayout(this); frame.addView(new GlassBackground(this),new android.widget.FrameLayout.LayoutParams(-1,-1)); frame.addView(root,new android.widget.FrameLayout.LayoutParams(-1,-1)); setContentView(frame);
        TextView title=Ui.label(this,"High Customization",30); title.setTypeface(null,Typeface.BOLD); root.addView(title,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
        TextView desc=Ui.label(this,"Tune popup behavior, center density, accents and your Boss Key.",15); desc.setTextColor(0xA8C6D8); root.addView(desc,new LinearLayout.LayoutParams(-1,Ui.dp(this,35)));
        android.widget.ScrollView sv=new android.widget.ScrollView(this); LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        addSlider(content,"Popup duration",1,20,AppPrefs.popupSeconds(this),v->{AppPrefs.setPopupSeconds(this,v);popupValue.setText(v+" seconds");},"popup");
        addSlider(content,"Maximum saved notifications",20,300,AppPrefs.maxNotifications(this),v->{AppPrefs.setMaxNotifications(this,v);maxValue.setText(String.valueOf(v));},"max");
        Switch icons=new Switch(this); icons.setText("Show app icons in popups"); icons.setTextColor(0xFFF7FBFF); icons.setTextSize(17); icons.setChecked(AppPrefs.showIcons(this)); icons.setOnCheckedChangeListener((b,checked)->AppPrefs.setShowIcons(this,checked)); content.addView(icons,new LinearLayout.LayoutParams(-1,Ui.dp(this,68)));
        addAccentRow(content);
        addPositionRow(content);
        LinearLayout keyRow=new LinearLayout(this); keyRow.setGravity(Gravity.CENTER_VERTICAL); TextView kl=Ui.label(this,"Boss Key",18); keyRow.addView(kl,new LinearLayout.LayoutParams(0,Ui.dp(this,70),1)); keyValue=Ui.label(this,KeyEvent.keyCodeToString(AppPrefs.bossKey(this)),15); keyValue.setTextColor(0xB9D2E5); keyRow.addView(keyValue,new LinearLayout.LayoutParams(Ui.dp(this,240),Ui.dp(this,70))); keyButton=Ui.button(this,"Press a key"); keyButton.setOnClickListener(v->{capturing=true;keyButton.setText("NOW PRESS REMOTE KEY");}); keyRow.addView(keyButton,new LinearLayout.LayoutParams(Ui.dp(this,230),Ui.dp(this,64))); content.addView(keyRow);
        Button access=Ui.button(this,"Enable global Boss Key (Accessibility)"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); content.addView(access,new LinearLayout.LayoutParams(-1,Ui.dp(this,64)));
        TextView bossHint=Ui.label(this,"Accessibility is optional. Android 11 does not expose a universal global shortcut API for arbitrary TV remote buttons.",13); bossHint.setTextColor(0x8FB2C9D6); content.addView(bossHint,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
    }
    private void addSlider(LinearLayout p,String name,int min,int max,int value,final ValueListener l,String kind){
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); TextView n=Ui.label(this,name,17); head.addView(n,new LinearLayout.LayoutParams(0,Ui.dp(this,38),1)); TextView v=Ui.label(this,String.valueOf(value),15); v.setTextColor(0xB9D2E5); head.addView(v,new LinearLayout.LayoutParams(Ui.dp(this,180),Ui.dp(this,38))); p.addView(head);
        if(kind.equals("popup"))popupValue=v;else maxValue=v;
        SeekBar s=new SeekBar(this); s.setMax(max-min); s.setProgress(value-min); s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int x,boolean from){l.onChange(x+min);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}}); p.addView(s,new LinearLayout.LayoutParams(-1,Ui.dp(this,54)));
    }
    private void addPositionRow(LinearLayout p){
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=Ui.label(this,"Popup position",17); r.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,68),1));
        String[] names={"Top right","Top left","Bottom right","Bottom left"}; String[] vals={"top_right","top_left","bottom_right","bottom_left"};
        for(int i=0;i<names.length;i++){ Button b=Ui.button(this,names[i]); final String value=vals[i]; b.setOnClickListener(v->AppPrefs.setPopupPosition(this,value)); r.addView(b,new LinearLayout.LayoutParams(Ui.dp(this,190),Ui.dp(this,60))); }
        p.addView(r);
    }
    private void addAccentRow(LinearLayout p){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView t=Ui.label(this,"Glass accent",17);r.addView(t,new LinearLayout.LayoutParams(0,Ui.dp(this,68),1));for(int i=0;i<accents.length;i++){Button b=Ui.button(this,"●");final int ix=i;b.setTextColor(accents[i]);b.setOnClickListener(v->AppPrefs.setAccentIndex(this,ix));r.addView(b,new LinearLayout.LayoutParams(Ui.dp(this,80),Ui.dp(this,60)));}p.addView(r);}
    interface ValueListener{void onChange(int v);}
    @Override public boolean onKeyDown(int code,KeyEvent e){if(capturing&&e.getAction()==KeyEvent.ACTION_DOWN){if(code==KeyEvent.KEYCODE_BACK)return true;AppPrefs.setBossKey(this,code);keyValue.setText(KeyEvent.keyCodeToString(code));keyButton.setText("Change key");capturing=false;return true;}return super.onKeyDown(code,e);}
}

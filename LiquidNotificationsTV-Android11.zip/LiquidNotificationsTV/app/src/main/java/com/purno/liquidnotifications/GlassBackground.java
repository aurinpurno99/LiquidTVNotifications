package com.purno.liquidnotifications;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

public class GlassBackground extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint blob = new Paint(Paint.ANTI_ALIAS_FLAG);
    public GlassBackground(Context c) { super(c); setWillNotDraw(false); }
    @Override protected void onDraw(Canvas c) {
        int w=getWidth(), h=getHeight();
        p.setShader(new LinearGradient(0,0,w,h,0xFF08111D,0xFF16283A,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);
        blob.setShader(new RadialGradient(w*0.18f,h*0.22f,w*0.48f,0x558BD7FF,0x001A2230,Shader.TileMode.CLAMP));
        c.drawCircle(w*0.18f,h*0.22f,w*0.48f,blob);
        blob.setShader(new RadialGradient(w*0.82f,h*0.18f,w*0.38f,0x5549B6A7,0x001A2230,Shader.TileMode.CLAMP));
        c.drawCircle(w*0.82f,h*0.18f,w*0.38f,blob);
        blob.setShader(new RadialGradient(w*0.62f,h*0.88f,w*0.55f,0x443A7BD5,0x001A2230,Shader.TileMode.CLAMP));
        c.drawCircle(w*0.62f,h*0.88f,w*0.55f,blob);
    }
}

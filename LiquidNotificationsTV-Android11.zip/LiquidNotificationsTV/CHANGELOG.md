# 1.0.0
- Initial Android 11 Google TV liquid-glass notification hub.
- Notification listener + overlay popups.
- All-apps or selected-app source filtering.
- Notification center with history.
- Configurable Boss Key with optional Accessibility global key filtering.
- TV D-pad friendly landscape UI.
